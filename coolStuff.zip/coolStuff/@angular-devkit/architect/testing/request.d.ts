export declare function request(url: string, headers?: {}): Promise<string>;
